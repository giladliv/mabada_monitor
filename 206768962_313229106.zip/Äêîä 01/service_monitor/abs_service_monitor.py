import platform
import threading
import time
from abc import abstractmethod
from hashlib import md5

import psutil
from datetime import datetime

WIN = 1
class service_monitor_realtime:
    def __init__(self):
        self.service_dict = {}
        self.is_continue = False

        #if Windows

    @staticmethod
    def get_curr_time():
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def write_all_services(self, wait_time: int = 10):
        th = threading.Thread(target=self.get_services, args=(wait_time,))
        self.is_continue = True
        th.start()
        req = ''
        print('press \'q\' to quit')
        while req != 'q':
            req = input()
        print('the monitor is closing... please wait until its done...')
        self.is_continue = False
        th.join(timeout=3)
        print("monitor has been closed")

    def get_services(self, wait_time: int = 10):
        print('monitor is running')
        while self.is_continue:
            curr_serv_stat = self.get_all_services_dict()
            self.write_to_log_running(curr_serv_stat)
            self.write_to_log_status(curr_serv_stat)
            time.sleep(wait_time)


    @abstractmethod
    def get_all_services_dict(self):
        pass

    def write_to_log_running(self, curr_serv_stat: dict):
        with open("serviceList.log", "a") as log_file:
            time_str = 'Time: [{}]\n'.format(service_monitor_realtime.get_curr_time())
            log_file.write(time_str)
            for serv in curr_serv_stat:
                status = curr_serv_stat[serv]
                if status == 'running':
                    str_line = serv + "\n"
                    log_file.write(str_line)
            log_file.write('\n')

    def write_to_log_status(self, curr_serv_stat: dict):
        status_template = 'time:{0}, service_name: \'{1}\', status: {2}, action: {3}'
        with open("Status_Log.txt", "a") as log_file:
            time_str = '[{}]'.format(service_monitor_realtime.get_curr_time())

            is_start_log = len(self.service_dict) == 0
            # check which service has been deleted from our computer
            for serv in self.service_dict:
                if serv not in curr_serv_stat:
                    status_line = status_template.format(time_str, serv, self.service_dict[serv], 'deleted')
                    log_file.write(status_line)
                    print(status_line)

            for serv in curr_serv_stat:
                c_status = ''
                action = ''
                if serv in self.service_dict:
                    if curr_serv_stat[serv] != self.service_dict[serv]:
                        action = 'exists'
                else:
                    action = 'new' if not is_start_log else 'exists'

                if action != '':
                    status_line = status_template.format(time_str, serv, curr_serv_stat[serv], action)
                    log_file.write(status_line + '\n')
                    print(status_line)
                self.service_dict[serv] = curr_serv_stat[serv]

            log_file.write('\n')

    def hash_line(self, s: str, end='\n'):
        s_bin = md5(s.encode()).digest()
        s_bin = md5(s_bin).digest()
        return s.encode() + s_bin + end.encode()

#
mon = service_monitor_realtime()
# mon.write_all_services(10)

mon.hash_line('hello')