import subprocess
from abs_service_monitor import service_monitor_realtime

class service_monitor_linux(service_monitor_realtime):

    def get_all_services_dict(self):
        ret_dict = {}
        proc = subprocess.run(["service", "--status-all"], stdout=subprocess.PIPE)
        for line in proc.stdout.decode().split('\n'):
            if line == '':
                continue
            service_name = line[8:]
            sign = line[3]
            status = 'running' if sign == '+' else 'stopped'
            ret_dict[service_name] = status
        return ret_dict

# mon = service_monitor_linux()
# mon.write_all_services(10)