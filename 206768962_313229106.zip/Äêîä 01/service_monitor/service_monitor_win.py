import psutil
from abs_service_monitor import service_monitor_realtime

class service_monitor_win(service_monitor_realtime):
    def get_all_services_dict(self):
        ret_dict = {}
        for serv in psutil.win_service_iter():
            ret_dict[serv.name()] = serv.status()
        return ret_dict

# mon = service_monitor_win()
# mon.write_all_services(10)