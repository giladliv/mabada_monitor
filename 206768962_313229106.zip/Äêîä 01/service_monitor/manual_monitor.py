import json
import time

class manual_monitor:
    def __init__(self):
        self.dateTimeDict = {}

    def __loadFile(self):
        self.dateTimeDict = {}
        with open('serviceList.log', 'r') as f:
            c_time = -1
            for line in f.readlines():

                splited = line.split(":")
                if len(splited) > 1 and splited[0] == 'Time' and line.find('Time: [') == 0:
                    ind = len('Time: [')
                    line = line[ind :-2]
                    print(line)
                    c_time = time.strptime(line, "%Y-%m-%d %H:%M:%S")
                    self.dateTimeDict[c_time] = []
                else:
                    if line != '':
                        self.dateTimeDict[c_time] += [line]

    def make_test(self, time1, time2):
        self.__loadFile()
        if time1 > time2:
            time1, time2 = time2, time1
        list_first = self.get_services_by_time(time1)
        list_second = self.get_services_by_time(time2)

        if list_first is None or list_second is None:       # if the dates are not compatible
            if list_first is None:
                print('the date ' + str(time1) + ' hasn\'t been founded')
            if list_second is None:
                print('the date ' + str(time2) + ' hasn\'t been founded')
            print('abort monitoring, please try again (can give times approximate by 1 minuet difference')
            return

        dict_services_status = {}
        for serv in list_first:
            if serv not in list_second:
                dict_services_status[serv] = False
        for serv in list_second:
            if serv not in list_first:
                dict_services_status[serv] = True


        print('Date #1: ' + time1.strftime("%Y-%m-%d %H:%M:%S"))
        print('Date #2: ' + time2.strftime("%Y-%m-%d %H:%M:%S"))
        print('here is the deductions from our monitor:')
        print()

        for serv in dict_services_status:
            if dict_services_status[serv]:
                print('new service {serv} started to run')
            else:
                print('the service {serv} stoped')

        if len(dict_services_status.keys()) == 0:
            print('there are no changes')

    def get_services_by_time(self, c_time):
        if c_time in self.dateTimeDict:
            return self.dateTimeDict[c_time]
        takeClosest = lambda num, collection: min(collection, key=lambda xy: abs(xy[1] - num))
        low_time = (takeClosest(c_time, self.dateTimeDict.keys()))
        if abs(low_time - c_time) <= 60:
            return self.dateTimeDict[low_time]
        return None

    def get_time(self):
        c_time = None
        while True:
            try:
                inp_date = input('please enter here a date [yyyy-mm-dd]: ')
                inp_time = input('please enter here a hour [hh:mm:ss]: ')
                c_time = time.strptime(inp_date + ' ' + inp_time, "%Y-%m-%d %H:%M:%S")
                break
            except:
                print('not a time format, please try again')
        return c_time

    def start_manual_moniroting(self):
        print('Time 1:')
        time1 = self.get_time()
        print('Time 2:')
        time2 = self.get_time()
        self.make_test(time1, time2)
