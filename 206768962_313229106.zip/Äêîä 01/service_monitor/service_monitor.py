import platform
import signal

from service_monitor_win import service_monitor_win
from service_monitor_linux import service_monitor_linux
from manual_monitor import manual_monitor


class monitor_program:
    def __init__(self):
        self.monitor = None
        plat_name = platform.system()
        if plat_name == 'Windows':
            self.monitor = service_monitor_win()
        elif plat_name == 'Linux':
            self.monitor = service_monitor_linux()
        signal.signal(signal.SIGINT, self.signal_handler)

    def menu(self, wait_time: int = 10):
        print('welcome to the our service monitor\n')
        choice = ''
        while choice != '3':
            choice = self.choose_from_menu()
            if choice == '1':
                wait_time = self.get_time_interval()
                self.monitor.write_all_services(wait_time)
            elif choice == '2':
                man_mon = manual_monitor()
                man_mon.start_manual_moniroting()
            elif choice == '3':
                print('goodbye')
            else:
                input('illegal input')

    def choose_from_menu(self):
        print('the options are: ')
        print('1. run an automatic monitor')
        print('2. manual monitor by 2 given occasion')
        print('3. quit the program')
        return input('please enter here your number of the options: ')

    def get_time_interval(self):
        wait_time = 0
        while wait_time <= 0:
            try:
                wait_time = input('enter here the time (in seconds) for the monitor interval: ')
                wait_time = float(wait_time)
                if wait_time <= 0:
                    print('the time must be positive number')
            except:
                print('the type on input must be floating number')
                wait_time = 0
        return wait_time

    def start_monitor(self, wait_time: int = 10):
        choice = ''
        print('welcome to the automatic monitor')
        print('after the monitor starts, you can stop it by')

        while choice != 'y' and choice != 'n':
            choice = input("do you want to start? [y/n]")
            choice = choice.lower()
            if choice != 'y' and choice != 'n':
                print('invalid choice - please try again')
        if choice == 'y':
            self.monitor.write_all_services(wait_time)
        else:
            print('back to the main menu')

    def signal_handler(signum, frame):
        print("Signal Number:", signum, " Frame: ", frame)

serv_mon = monitor_program()
serv_mon.menu()